# DAILY_ANCHOR_API.md — Merkle root daily anchor + blockchain submission

## แนวคิด: ค้ำยันไทย-USA 100% โดยไม่ต้องขอเวลาจากที่อื่น

### Flow รายวัน (00:00 UTC)
```
[PostgreSQL append-only: tokens ของวัน]
   |
   | สร้าง Merkle Tree จาก sha256+tokenId+tstSignature ทั้งหมด
   v
[Merkle Root ของวัน: 0x...]
   |
   | ส่งไป Public Chain (Polygon / BNB Chain - ค่าแก๊สต่ำ)
   v
[Smart Contract: DailyAnchor.sol]
  function anchorRoot(bytes32 root, uint256 date) onlyOwner
   |
   v
[Public Chain Tx: 0xabc...] -> ทุกคนตรวจสอบได้
```

## API

### GET /anchor/status
```json
{
  "todayCount": 127,
  "pendingRoot": "0x...",
  "lastAnchored": {
    "date": "2026-09-27",
    "root": "0x...",
    "txHash": "0x...",
    "chain": "Polygon"
  }
}
```

### POST /anchor/force (admin only)
บังคับ anchor ทันที (สำหรับ Proof แรกของโลก 27 Sep 2026)

### Smart Contract (ตัวอย่าง)
```solidity
// SPDX-License-Identifier: MIT
contract DailyAnchor {
  mapping(uint256 => bytes32) public roots;
  event Anchored(uint256 date, bytes32 root, bytes32 indexed tx);
  function anchorRoot(uint256 date, bytes32 root) external onlyOwner {
    roots[date] = root;
    emit Anchored(date, root, root);
  }
}
```

### ต้นทุน
- Gas: ~$0.05-0.20/วัน บน Polygon
- รวม < $10/เดือน
- ทำให้ BTM-TOKEN อยู่กับเรา 100% แต่ Proof อยู่บน public chain ที่ลบไม่ได้
