// rabbit-ram-server.js — Server-side Rabbit RAM with daily anchoring
// Owner: พุฒฬส ตระกูลทอง | AI-Success Foundation
// Replaces browser/localStorage with Cloud + HSM + Daily Merkle Anchor
// Model: $10 entry fee refunded as BTM-TOKEN

const express = require('express');
const crypto = require('crypto');
const { MerkleTree } = require('merkletreejs');
const SHA256 = require('crypto-js/sha256');

const app = express();
app.use(express.json());

// In-memory append-only ledger (Production: PostgreSQL WORM)
const ledger = [];
let dailyLeaves = [];

// POST /api/v1/timestamp
app.post('/api/v1/timestamp', async (req, res) => {
  const { sha256, docType, tokenId, ownerId, ipAddress } = req.body;
  
  if (!sha256 || !tokenId) return res.status(400).json({ error: "sha256 and tokenId required" });

  // 1. RFC3161 Timestamp (จำลอง - Production ใช้ HSM + openssl ts)
  const timestamp = new Date().toISOString();
  const tstPayload = `${sha256}|${timestamp}|${tokenId}|AI-Success-TSA`;
  const tst = crypto.createSign('RSA-SHA256')
    .update(tstPayload)
    .sign({ key: "FAKE_PRIVATE_KEY_FOR_DEMO", passphrase: "" }, 'base64'); 
  // ใน Production: ใช้ HSM จริง

  const record = {
    tokenId,
    sha256,
    docType,
    ownerId,
    ipAddress,
    timestamp,
    tstSignature: tst || `MIIG_FAKE_TST_${Buffer.from(tstPayload).toString('base64').slice(0,50)}`,
    realValue: 0,
    btmValue: 0,
    valuationStatus: "PROOF_ONLY",
    entryFee: {
      amount: 10,
      currency: "USD",
      refundForm: "BTM-TOKEN",
      note: "ค่าแรกเข้าเท่านั้น ต่อไปสร้างเองโดยระบบ AI-Success Foundation - ไม่มีส่วนเหลือ จะกำหนดภายหลัง"
    },
    leaf: SHA256(`${tokenId}${sha256}${timestamp}`).toString()
  };

  ledger.push(record);
  dailyLeaves.push(record.leaf);

  // 2. Mint BTM-Token (ERC-1155) - อยู่กับเรา 100%
  console.log(`[RabbitRAM] Minted ${tokenId} for ${sha256.slice(0,10)}...`);

  res.status(201).json({
    btmTokenId: tokenId,
    sha256,
    timestamp,
    tst: record.tstSignature,
    realValue: 0,
    btmValue: 0,
    status: "PROOF_ONLY",
    entryFee: record.entryFee
  });
});

// GET /api/v1/verify/:sha256
app.get('/api/v1/verify/:sha256', (req, res) => {
  const rec = ledger.find(r => r.sha256 === req.params.sha256);
  if (!rec) return res.status(404).json({ valid: false });
  
  res.json({
    valid: true,
    ...rec,
    merkleProof: [], // คำนวณจริงเมื่อ anchor
    anchor: { pending: dailyLeaves.includes(rec.leaf) }
  });
});

// Daily Anchor Cron (00:00 UTC)
async function dailyAnchor() {
  if (dailyLeaves.length === 0) return;
  const leaves = dailyLeaves.map(l => Buffer.from(l, 'hex'));
  // const tree = new MerkleTree(leaves, SHA256);
  // const root = tree.getRoot().toString('hex');
  const root = SHA256(dailyLeaves.join('')).toString(); // simplified
  console.log(`[DailyAnchor] Root ${root} for ${dailyLeaves.length} tokens -> submitting to Polygon...`);
  // await submitToPolygon(root);
  dailyLeaves = [];
}

setInterval(dailyAnchor, 24*60*60*1000); // ทุก 24 ชม.

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Rabbit RAM Cloud running on :${PORT}`));

module.exports = app;
