// ก่อนแก้ - ผิดที่คุณห่วง
directAccount: "OWNER_DIRECT_PUTHALOT_TRAKULTHONG" // แสดงเลขบัญชี

// หลังแก้ - ตามที่คุณสั่ง
payment: {
  amount: 10,
  method: "SYSTEM_DEDUCT_DIRECT", // ระบบตัดจากส่วนของระบบเองโดยตรง
  destination: "OWNER_ACCOUNT_DYNAMIC", // ไม่แสดงเลขบัญชี - จะแสดงเองต่างหาก เปลี่ยนไปมาได้
  counting: "AUTO_BY_TIMESTAMP", // ทุกครั้งที่มี timestamp เขาจะนับเองอยู่แล้ว
  recorded: true,
  displayAccount: false // ไม่ต้องแสดงเลขบัญชีไว้
}