# TIMESTAMP_API.md — RFC3161-style timestamp service contract

Base: `https://timestamp.aisuccess.team/api/v1`

## POST /timestamp
ออก BTM-Token พร้อมประทับเวลา RFC3161

**Request**
```json
{
  "sha256": "d1afa4758b3cd2d1ee1980283a5e43c784a04c38c289b645ccf6578b4816b7f7",
  "docType": "LEO-3C-PATENT|LAND_TITLE|FACTORY_LICENSE|TAX_RECEIPT",
  "tokenId": "BTM-LEO3C-20260927-0001",
  "ownerId": "bhudhose",
  "ipAddress": "203.0.113.10"
}
```

**Response 201**
```json
{
  "btmTokenId": "BTM-LEO3C-20260927-0001",
  "sha256": "d1afa475...",
  "timestamp": "2026-09-27T07:18:00+07:00",
  "tst": "MIIG... (Base64 RFC3161 TimeStampToken)",
  "realValue": 0,
  "btmValue": 0,
  "status": "PROOF_ONLY",
  "entryFee": { "amount": 10, "currency": "USD", "refundForm": "BTM-TOKEN" }
}
```

## GET /verify/:sha256
ตรวจสอบย้อนหลัง

**Response 200**
```json
{
  "valid": true,
  "sha256": "d1afa475...",
  "btmTokenId": "BTM-LEO3C-20260927-0001",
  "timestamp": "2026-09-27T07:18:00+07:00",
  "tstSignature": "MIIG...",
  "merkleProof": ["a1b2...", "c3d4..."],
  "dailyRoot": "e5f6...",
  "anchor": {
    "chain": "Polygon",
    "txHash": "0x...",
    "anchoredAt": "2026-09-28T00:00:00Z"
  }
}
```

## Security
- TSA Private Key อยู่ใน HSM - ไม่ได้อยู่บน server
- NTP Stratum 1 Sync
- Append-only DB
