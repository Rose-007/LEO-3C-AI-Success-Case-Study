# TOKEN_SCHEMA.md — โครงสร้าง token พร้อม proof + valuation layers
> Model: $10 ค่าแรกเข้าเท่านั้น คืนในรูป BTM-TOKEN | ไม่ควรมีส่วนเหลือ - จะกำหนดอีกทีภายหลัง

## Base Token (จาก Gt. Module)
```json
{
  "tokenId": "unique_id",
  "createdAt": "timestamp",
  "ipAddress": "source_ip",
  "status": "Order|Exception|Solved|Match"
}
```

## v2 Cloud-Backed Full Schema (ปัจจุบัน)
```json
{
  "tokenId": "BTM-LEO3C-20260927-0001",
  "sha256": "d1afa4758b3cd2d1ee1980283a5e43c784a04c38c289b645ccf6578b4816b7f7",
  "tstSignature": "MIIG... RFC3161 Token จาก Timestamp Cloud ของเรา",
  "createdAt": "2026-09-27T07:18:00+07:00",
  "timestamp": "2026-09-27T07:18:00+07:00",
  "ipAddress": "source_ip",
  "status": "Order|Exception|Solved|Match",
  "count": 1,
  "costIncurred": 0,
  "royalty": 0,
  "realValue": 0,
  "btmValue": 0,
  "valuationStatus": "PROOF_ONLY",
  "entryFee": {
    "amount": 10,
    "currency": "USD",
    "refundForm": "BTM-TOKEN",
    "note": "ค่าแรกเข้าเท่านั้น ต่อไปไม่ต้องเก็บ เพราะสร้างเองโดยระบบ AI-Success Foundation"
  },
  "metadata": {
    "owner": "พุฒฬส ตระกูลทอง",
    "docType": "LEO-3C-PATENT",
    "chainId": "LEO3C-20260927-AISUCCESS",
    "parentCompanyContract": true,
    "notMetaDirect": true
  },
  "merkle": {
    "leaf": "sha256(tokenId+sha256+tstSignature)",
    "dailyRoot": "pending",
    "anchorTx": "pending"
  }
}
```

### Valuation Layers
- **PROOF_ONLY**: มี sha256 + tstSignature แล้ว มูลค่า=0 (เหมือนขุด)
- **ACTIVATED**: เอาไปใช้งานจริง (โฉนดค้ำประกัน, โรงงานผลิต)
- **VALUED**: Smart Contract เติม realValue อัตโนมัติ - ไม่เกี่ยวกับ $10 แรกเข้า

### กฎสำคัญ
- ไม่มีคำว่า "ส่วนเหลือ" - จะกำหนดอีกทีภายหลัง
- $10 คืนในรูป BTM-TOKEN เท่านั้น
