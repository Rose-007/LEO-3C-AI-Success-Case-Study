// script.js v2 — Cloud-backed Rabbit RAM (ไม่ใช่ localStorage)
// Owner: พุฒฬส ตระกูลทอง | AI-Success Foundation
// Model: $10 ค่าแรกเข้าเท่านั้น คืนในรูป BTM-TOKEN | ไม่มีส่วนเหลือ - จะกำหนดอีกทีภายหลัง

const TIMESTAMP_CLOUD_URL = "https://timestamp.aisuccess.team/api/v1";

class RabbitRAMCloud {
  constructor() {
    this.tokenCounter = 0;
    // ไม่ใช้ localStorage อีกต่อไป
  }

  async createToken({ docType, sha256, ownerId, ipAddress }) {
    this.tokenCounter++;
    const tokenId = `BTM-LEO3C-${new Date().toISOString().slice(0,10).replace(/-/g,'')}-${String(this.tokenCounter).padStart(4,'0')}`;
    
    const payload = {
      tokenId,
      sha256: sha256, // d1afa4758b3cd2d1ee1980283a5e43c784a04c38c289b645ccf6578b4816b7f7 for LEO-3C
      docType,
      ownerId,
      ipAddress,
      count: 1,
      costIncurred: 0,
      royalty: 0,
      realValue: 0,
      btmValue: 0,
      valuationStatus: "PROOF_ONLY",
      createdAt: new Date().toISOString(),
      status: "Order"
    };

    // 2. ส่งไป Cloud เราโดยตรง - ไม่ผ่าน localStorage
    return await this.syncToCloud(payload);
  }

  async syncToCloud(payload) {
    try {
      const res = await fetch(`${TIMESTAMP_CLOUD_URL}/timestamp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sha256: payload.sha256,
          docType: payload.docType,
          tokenId: payload.tokenId,
          ownerId: payload.ownerId,
          ipAddress: payload.ipAddress
        })
      });
      const data = await res.json();
      return {
        ...payload,
        tstSignature: data.tst,
        timestamp: data.timestamp,
        btmTokenId: data.btmTokenId,
        merklePending: true
      };
    } catch (e) {
      console.error("RabbitRAM Cloud Sync Failed", e);
      // Fallback: queue for retry - still not localStorage
      return { ...payload, syncStatus: "QUEUED_RETRY" };
    }
  }

  async verifyToken(sha256) {
    const res = await fetch(`${TIMESTAMP_CLOUD_URL}/verify/${sha256}`);
    return res.json();
  }
}

// Export for Gt. GitHub Module
if (typeof module !== 'undefined') {
  module.exports = RabbitRAMCloud;
}
